#!/bin/bash

/usr/bin/helm unittest --color ./traefik;
